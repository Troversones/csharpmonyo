﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        #region Public integers;
        public static string termekn2, tipus2, kepek2;
        public static int ar2, boltikod2, megakarokhalni;
        public static List<string> mia = new List<string>();
        public static List<int> árvíz = new List<int>();
        public static Form2 xd = new Form2();
        #endregion Public integers;

        public Form1()
        {
            InitializeComponent();            
        }
        public static int azonosito;
        public static MySqlConnection Conn = new MySqlConnection("ssl mode=0;datasource=localhost;port=3306;username=root;password=;");
        public static MySqlDataAdapter adapt = new MySqlDataAdapter("SELECT * FROM csharp1.kekw", Conn);
        private void Form1_Load(object sender, EventArgs e)
        {            
            #region Connection;
            try
            {
                if (Conn.State == ConnectionState.Closed)
                {
                    Conn.Open();
                }
                DataSet ds = new DataSet();
                adapt.Fill(ds, "csharp1");
                dataGridView1.DataSource = ds.Tables["csharp1"];
                if (Conn.State == ConnectionState.Open)
                {
                    label1.Text = "Connected";
                    label1.ForeColor = Color.Green;
                }
                else
                {
                    label1.Text = "Not connected";
                    label1.ForeColor = Color.Red;
                }
                
            }
            catch (Exception xd)
            {
                MessageBox.Show(xd.Message);
                throw;
            }

            #endregion Connection;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            #region Open Connect;
            if (Conn.State == ConnectionState.Closed)
            {
                Conn.Open();
            }

            if (Conn.State == ConnectionState.Open)
            {
                label1.Text = "Connected";
                label1.ForeColor = Color.Green;
            }
            else
            {
                label1.Text = "Not connected";
                label1.ForeColor = Color.Red;
            }
            #endregion Open Connect;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            #region Close Connect;
            if (Conn.State == ConnectionState.Open)
            {
                Conn.Close();
            }

            if (Conn.State == ConnectionState.Open)
            {
                label1.Text = "Connected";
                label1.ForeColor = Color.Green;
            }
            else
            {
                label1.Text = "Not connected";
                label1.ForeColor = Color.Red;
            }
            #endregion Close Connect;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            #region INSERT;
            try
            {
                string xd = "INSERT INTO csharp1.kekw(Termeknev,Ar,Tipus,Boltikod,Kepek) values('"+this.textBox1.Text +"','"+this.textBox2.Text+"','"+this.textBox3.Text+"','"+this.textBox4.Text+"','"+this.textBox5.Text+"');";
                MySqlCommand xdd = new MySqlCommand(xd, Conn);
                MySqlDataReader cmd2;
                if (Conn.State == ConnectionState.Closed)
                {
                    Conn.Open();
                }
                cmd2 = xdd.ExecuteReader();
                MessageBox.Show("Save Data");
                while (cmd2.Read())
                {
                }
                Conn.Close();
                DataSet ds = new DataSet();
                adapt.Fill(ds, "csharp1");
                dataGridView1.DataSource = ds.Tables["csharp1"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            #endregion INSERT;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            #region UPDATE;
            try
            {
                string comm = "update csharp1.kekw set Termeknev='" + this.textBox1.Text + "',Ar='" + this.textBox2.Text + "',Tipus='" + this.textBox3.Text + "',Boltikod='" + this.textBox4.Text + "',Kepek='"+this.textBox5.Text+ "' where Boltikod='" + azonosito+"';";
                MySqlCommand update = new MySqlCommand(comm, Conn);
                MySqlDataReader cmd2;
                if (Conn.State == ConnectionState.Closed)
                {
                    Conn.Open();
                }

                cmd2 = update.ExecuteReader();
                MessageBox.Show("Data updated");
                while (cmd2.Read())
                {

                }
                Conn.Close();
                DataSet ds = new DataSet();
                adapt.Fill(ds, "csharp1");
                dataGridView1.DataSource = ds.Tables["csharp1"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }
            #endregion UPDATE;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string text1, text2, text3, text4, text5;
            #region Textbox feltöltés;
            try
            {
                text1 = dataGridView1.SelectedRows[0].Cells[0].Value + string.Empty;
                text2 = dataGridView1.SelectedRows[0].Cells[1].Value + string.Empty;
                text3 = dataGridView1.SelectedRows[0].Cells[2].Value + string.Empty;
                text4 = dataGridView1.SelectedRows[0].Cells[3].Value + string.Empty;
                text5 = dataGridView1.SelectedRows[0].Cells[4].Value + string.Empty;
                textBox1.Text = text1;
                textBox2.Text = text2;
                textBox3.Text = text3;
                textBox4.Text = text4;
                textBox5.Text = text5;
                azonosito = int.Parse(dataGridView1.SelectedRows[0].Cells[3].Value.ToString());
            }
            catch (Exception kex)
            {
                MessageBox.Show("Ne cellát hanem sort válassz ki. Lásd: "+kex.Message);
            }

            #endregion Textbox feltöltés;
            try
            {
                text5 = textBox5.Text;
                
                this.pictureBox1.Image = Image.FromFile(text5);
               

            }
            catch (Exception ex)
            {
                MessageBox.Show("A kép nem létezik a jelenlegi kontextusban! Lásd: " + ex.Message);
            }
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            xd.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            #region DELETE;
            try
            {
                string xd = "delete from csharp1.kekw where Boltikod='" + this.textBox4.Text+"';";
                MySqlCommand xdd = new MySqlCommand(xd, Conn);
                MySqlDataReader cmd2;
                if (Conn.State == ConnectionState.Closed)
                {
                    Conn.Open();
                }
                cmd2 = xdd.ExecuteReader();
                MessageBox.Show("Data deleted");
                while (cmd2.Read())
                {
                }
                Conn.Close();
                DataSet ds = new DataSet();
                adapt.Fill(ds, "csharp1");
                dataGridView1.DataSource = ds.Tables["csharp1"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }
            #endregion DELETE;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            #region ellenőrzés;
            if (numericUpDown1.Value < 1)
            {
                MessageBox.Show("1 vagy nagyobb mennyiséget adj meg!");
            }

            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Kérlek válassz ki egy terméket egy sor \r\n kijelölésével és a kiválasztás gombra nyomva!");
            }
            else
            {
                #endregion ellenőrzés;
                #region ár átalakítás stringből intbe;
                string xd = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                string output = new string(xd.ToCharArray().Where(c => char.IsDigit(c)).ToArray());
                int ar = int.Parse(output);
                #endregion ár átalakítás stringből intbe;
                #region Publikus változók feltöltése;
                termekn2 = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                ar2 = ar;
                tipus2 = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                boltikod2 = int.Parse(dataGridView1.SelectedRows[0].Cells[3].Value.ToString());
                kepek2 = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                MessageBox.Show("A(z) " + termekn2 + " termékből " + numericUpDown1.Value + " db" + " a kosárba lett helyezve!");
                megakarokhalni = int.Parse(numericUpDown1.Value.ToString());
                #region Reset;
                numericUpDown1.Value = 1;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                this.pictureBox1.Image = null;
                #endregion Reset;
                #endregion Publikus változók feltöltése;
                #region Lista feltöltés;
                for (int i = 0; i < 1; i++)
                {
                    árvíz.Add(ar);
                    mia.Add(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                }
                #endregion Lista feltöltés;
            }
        }
    }
}
