﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp3
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            #region változók;
            string termeknev, tipus;
            int miert, ar, boltikod;
            int haver = 0;
            termeknev = Form1.termekn2;
            tipus = Form1.tipus2;
            ar = Form1.ar2;
            boltikod = Form1.boltikod2;
            miert = Form1.megakarokhalni;
            List<int> hehe = new List<int>(Form1.árvíz);
            List<string> haha = new List<string>(Form1.mia);
            
            #endregion változók;
            #region Listbox feltoltes;
            for (int i = 0; i < hehe.Count; i++)
            {
                listBox1.Items.Add(hehe[i] * miert + " Ft");
                haver = haver + (hehe[i] * miert);
            }
            for (int i = 0; i < haha.Count; i++)
            {
                listBox2.Items.Add(haha[i]);
            }
            #endregion Listbox feltoltes;
            label10.Text = haver.ToString() + " Ft";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form1 vissza = new Form1();
            vissza.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string date = DateTime.Now.ToLongDateString() + ".txt";
            StreamWriter iro = new StreamWriter(date,true);
            iro.WriteLine("---------------------------------");
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                iro.WriteLine("Terméknév: " + listBox2.Items[i] + " //   Ár: " + listBox1.Items[i]);
            }
            iro.WriteLine("Fizetendő összeg: " + label10.Text);
            iro.WriteLine("---------------------------------");
            iro.Close();
            MessageBox.Show("Köszönjük a vásárlást!");
            this.Close();
        }
    }
}
